import time
import random

# variables
listWeapons = ["Sword of ogoroth", "Magical Staff", "Dragon blade Shusui"]
listMonsters = ["Kraken", "Goliath", "Goblin"]
randMonster = random.choice(listMonsters)
randWeapon = random.choice(listWeapons)
item = []


def prompt(message):
    print(message)
    time.sleep(1)


def intro():
    prompt("You find yourself standing in an open field, filled with grass "
           "and yellow wildflowers.")
    prompt("Rumor has it that a " + randMonster + " is somewhere around here, "
           "and has been terrifying the nearby village.")
    prompt("In front of you is a house.")
    prompt("To your right is a dark cave")
    prompt("In your hand you hold your trusty (but no very effective) dagger")


def where():
    prompt("Enter 1 to knock on the door of the house")
    prompt("Enter 2 to peer into the cave")
    choice = input("What would you like to do? \n Please enter 1 or 2\n")
    if choice == '1':
        house()
    elif choice == '2':
        cave()
    else:
        prompt("Choose a valid entry")
        where()


def cave():
    prompt("You peer cautiosly into the cave")
    prompt("It turns out to be only a very small cave")
    prompt("YOur eye catches a flint of metal behind a rock")
    prompt("You have found the " + randWeapon + "")
    prompt("You discard your silly old dagger and take the " + randWeapon +
           "with you")
    item.append("sword")
    prompt("You walk back out to the field")
    where()


def house():
    prompt("You approach the door of the house")
    prompt("You are about to knock when the door opens and out steps a "
           + randMonster)
    prompt("Eep! This is the " + randMonster + " house!")
    prompt("Would you like to (1) fight or (2) run away")
    choice = input("Please enter 1 or 2:\n")
    if choice == '1' and 'sword' not in item:
        prompt("You feel a bit under prepared for this, with only having a "
               "tiny dagger")
        prompt("You do your best")
        prompt("but your dagger is no match for the " + randMonster + ".")
        prompt("You have been defeated")
        playAgain()
    elif choice == "1" and 'sword' in item:
        prompt("As the " + randMonster + " moves to attack, you unleash your "
               "new weapon")
        prompt("The " + randWeapon + " shines brightly in your hand as you "
               "brace yourself to the attack")
        prompt("As the" + randMonster + " takes one look at your shiny new "
               "toy and runs away!")
        prompt("You have rid the town of the " + randMonster + ".")
        playAgain()
    elif choice == '2':
        prompt("You run back to the field. Luckily, you don't seem to have "
               "been followed")
        where()
    else:
        prompt("Enter a valid entry!")
        fight()


def playAgain():
    choice = input("Would you like to play again? Enter (y) yes or (n) no.")
    if choice == 'y':
        prompt("Excellent Restaring game...")
        playGame()
    elif choice == 'n':
        prompt("Ok see you next time.")
    else:
        prompt("Enter a valid entry: ")
        playAgain()


def playGame():
    item = []
    intro()
    where()


playGame()
